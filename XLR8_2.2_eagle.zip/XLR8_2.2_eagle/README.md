# Alorium Technology XLR8

Eagle-formatted PCB files for Alorium Technology XLR8 board from svn 2601

Designed by Alorium Technology, LLC
Released under the Creative Commons Attribution Share-Alike 4.0 License
https://creativecommons.org/licenses/by-sa/4.0/

All text above must be included in any redistribution
